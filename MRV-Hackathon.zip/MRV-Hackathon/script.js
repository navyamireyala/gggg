let array = [];

let steps = 0;
let comparisons = 0;
let isRunning = false;

const arrayInput = document.getElementById("arrayInput");
const algorithm = document.getElementById("algorithm");
const searchSection = document.getElementById("searchSection");
const algorithmDescription =
    document.getElementById("algorithmDescription");


// ===============================
// RANDOM ARRAY
// ===============================

function generateArray() {

    array = [];

    for (let i = 0; i < 10; i++) {
        array.push(Math.floor(Math.random() * 90) + 10);
    }

    arrayInput.value = array.join(", ");

    displayArray();
}


// ===============================
// DISPLAY ARRAY
// ===============================

function displayArray(highlightIndices = [], specialIndex = -1) {

    const container =
        document.getElementById("arrayContainer");

    container.innerHTML = "";

    if (array.length === 0) {
        return;
    }

    const maxValue = Math.max(...array);

    array.forEach((value, index) => {

        const bar = document.createElement("div");

        bar.className = "bar";

        const height =
            (value / maxValue) * 220;

        bar.style.height = height + "px";

        bar.textContent = value;

        if (highlightIndices.includes(index)) {
            bar.style.background = "orange";
        }

        if (index === specialIndex) {
            bar.style.background = "red";
        }

        container.appendChild(bar);
    });
}


// ===============================
// READ ARRAY
// ===============================

function readArray() {

    const input = arrayInput.value.trim();

    if (input === "") {

        alert("Please enter some numbers.");

        return false;
    }

    array = input
        .split(",")
        .map(Number)
        .filter(value => !isNaN(value));

    if (array.length === 0) {

        alert("Please enter valid numbers.");

        return false;
    }

    displayArray();

    return true;
}


// ===============================
// UPDATE STATISTICS
// ===============================

function updateStats() {

    document.getElementById("steps").textContent =
        steps;

    document.getElementById("comparisons").textContent =
        comparisons;
}


// ===============================
// DELAY FOR ANIMATION
// ===============================

function delay(ms) {

    return new Promise(resolve => {
        setTimeout(resolve, ms);
    });
}


// ===============================
// START ALGORITHM
// ===============================

async function startAlgorithm() {

    if (isRunning) {
        return;
    }

    if (!readArray()) {
        return;
    }

    steps = 0;
    comparisons = 0;

    updateStats();

    const selectedAlgorithm =
        algorithm.value;

    isRunning = true;

    const startTime = performance.now();

    if (selectedAlgorithm === "merge") {

        await mergeSort();

    }

    else if (selectedAlgorithm === "quick") {

        await quickSort(0, array.length - 1);

    }

    else if (selectedAlgorithm === "binary") {

        const searchValue =
            document.getElementById("searchValue").value;

        if (searchValue === "") {

            alert("Please enter a search value.");

            isRunning = false;

            return;
        }

        // Binary search requires sorted data
        array.sort((a, b) => a - b);

        displayArray();

        await delay(500);

        await binarySearch(
            Number(searchValue)
        );
    }

    const endTime = performance.now();

    document.getElementById("time").textContent =
        (endTime - startTime).toFixed(2) + " ms";

    displayArray();

    isRunning = false;
}


// =====================================================
// MERGE SORT
// =====================================================

async function mergeSort() {

    await mergeSortRecursive(
        0,
        array.length - 1
    );
}


async function mergeSortRecursive(left, right) {

    if (left >= right) {
        return;
    }

    const middle =
        Math.floor((left + right) / 2);

    steps++;

    updateStats();

    // Show division
    displayArray(
        createRange(left, right)
    );

    await delay(400);

    await mergeSortRecursive(
        left,
        middle
    );

    await mergeSortRecursive(
        middle + 1,
        right
    );

    await merge(
        left,
        middle,
        right
    );
}


async function merge(left, middle, right) {

    const leftPart =
        array.slice(left, middle + 1);

    const rightPart =
        array.slice(middle + 1, right + 1);

    let i = 0;
    let j = 0;
    let k = left;

    while (
        i < leftPart.length &&
        j < rightPart.length
    ) {

        comparisons++;

        steps++;

        updateStats();

        displayArray(
            [],
            k
        );

        await delay(350);

        if (leftPart[i] <= rightPart[j]) {

            array[k] = leftPart[i];

            i++;

        } else {

            array[k] = rightPart[j];

            j++;
        }

        k++;

    }


    while (i < leftPart.length) {

        array[k] = leftPart[i];

        i++;
        k++;

        steps++;

        updateStats();

        displayArray([], k - 1);

        await delay(250);
    }


    while (j < rightPart.length) {

        array[k] = rightPart[j];

        j++;
        k++;

        steps++;

        updateStats();

        displayArray([], k - 1);

        await delay(250);
    }
}


// =====================================================
// QUICK SORT
// =====================================================

async function quickSort(left, right) {

    if (left >= right) {
        return;
    }

    const pivotIndex =
        await partition(left, right);

    await quickSort(
        left,
        pivotIndex - 1
    );

    await quickSort(
        pivotIndex + 1,
        right
    );
}


async function partition(left, right) {

    const pivot =
        array[right];

    let i = left - 1;

    for (
        let j = left;
        j < right;
        j++
    ) {

        comparisons++;

        steps++;

        updateStats();

        // Highlight current comparison
        displayArray(
            [j],
            right
        );

        await delay(350);

        if (array[j] < pivot) {

            i++;

            // Swap
            let temp = array[i];

            array[i] = array[j];

            array[j] = temp;

            steps++;

            updateStats();

            displayArray(
                [i, j],
                right
            );

            await delay(350);
        }
    }

    // Put pivot in correct position
    let temp = array[i + 1];

    array[i + 1] = array[right];

    array[right] = temp;

    steps++;

    updateStats();

    displayArray(
        [],
        i + 1
    );

    await delay(500);

    return i + 1;
}


// =====================================================
// BINARY SEARCH
// =====================================================

async function binarySearch(target) {

    let left = 0;

    let right =
        array.length - 1;

    while (left <= right) {

        steps++;

        updateStats();

        const middle =
            Math.floor(
                (left + right) / 2
            );

        displayArray(
            [left, right],
            middle
        );

        await delay(700);

        comparisons++;

        updateStats();

        if (array[middle] === target) {

            displayArray(
                [],
                middle
            );

            await delay(700);

            alert(
                "Value " +
                target +
                " found at index " +
                middle
            );

            return;
        }

        if (array[middle] < target) {

            left = middle + 1;

        } else {

            right = middle - 1;
        }

        await delay(400);
    }

    alert(
        "Value " +
        target +
        " was not found."
    );
}


// =====================================================
// CREATE RANGE FOR VISUALIZATION
// =====================================================

function createRange(start, end) {

    const result = [];

    for (
        let i = start;
        i <= end;
        i++
    ) {

        result.push(i);
    }

    return result;
}


// =====================================================
// RESET
// =====================================================

function resetVisualizer() {

    if (isRunning) {
        return;
    }

    array = [];

    steps = 0;

    comparisons = 0;

    arrayInput.value = "";

    document.getElementById(
        "searchValue"
    ).value = "";

    document.getElementById(
        "arrayContainer"
    ).innerHTML = "";

    document.getElementById(
        "steps"
    ).textContent = "0";

    document.getElementById(
        "comparisons"
    ).textContent = "0";

    document.getElementById(
        "time"
    ).textContent = "0 ms";
}


// =====================================================
// ALGORITHM DESCRIPTION
// =====================================================

algorithm.addEventListener(
    "change",
    function () {

        if (algorithm.value === "merge") {

            algorithmDescription.textContent =
                "Merge Sort divides the array into smaller parts, recursively sorts them, and merges the sorted parts together. Time Complexity: O(n log n).";

            searchSection.style.display =
                "none";
        }

        else if (algorithm.value === "quick") {

            algorithmDescription.textContent =
                "Quick Sort selects a pivot and partitions the array around that pivot. The process is repeated recursively. Average Time Complexity: O(n log n).";

            searchSection.style.display =
                "none";
        }

        else {

            algorithmDescription.textContent =
                "Binary Search works on sorted data. It repeatedly divides the search interval in half until the target is found or the interval becomes empty. Time Complexity: O(log n).";

            searchSection.style.display =
                "block";
        }
    }
);


// =====================================================
// INITIAL SETUP
// =====================================================

generateArray();

algorithm.dispatchEvent(
    new Event("change")
);